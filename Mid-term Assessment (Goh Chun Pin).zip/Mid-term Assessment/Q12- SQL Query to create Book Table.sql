USE NCS2020

CREATE TABLE Book(Id int PRIMARY KEY,
Name varchar(50) NOT NULL,
Author_Name varchar(50),
Publishing_Date date DEFAULT GETDATE(),
Price int,);

INSERT INTO Book VALUES
(001,'Dot Net','Jeremy Chan','01-20-22',200),
(002,'Python','John Loh','10-30-22',300),
(003,'Java','Anderson','05-29-15',105),
(004,'SQL','James','01-25-19',293),
(005,'Power BI','Ricky Lee','01-10-21',210)