﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Mid_Term_Assessment
{
    public class Q4
    {
        public string username { get; set; }
        public string password { get; set; }

        public Q4(string username, string password)
        {
            this.username = username;
            this.password = password;
        }
    }


    internal class Program
    {
        public static string Q6(int n)
        {
            string[] roman = { "MMM", "MM", "M", "CM", "DCCC", "DCC", "DC", "D", "CD", "CCC", "CC", "C", "XC", "LXXX", "LXX", "LX", "L", "XL", "XXX", "XX", "X", "IX", "VIII", "VII", "VI", "V", "IV", "III", "II", "I" };
            int[] int_value = { 3000, 2000, 1000, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

            var roman_numerals = new StringBuilder();
            int i = 0;
            while (n != 0)
            {
                if (n >= int_value[i])
                {
                    n -= int_value[i];
                    roman_numerals.Append(roman[i]);
                }
                else
                {
                    i++;
                }
            }
            return roman_numerals.ToString();
        }

        static void Main(string[] args)
        {
            //Q1. Write a program in C# Sharp to find the sum of all elements of the array.  
            int[] myList = new int[3];
            myList[0] = 2;
            myList[1] = 5;
            myList[2] = 8;

            int myList_sum = 0;
            foreach (int item in myList)
            {
                myList_sum = item + myList_sum;
            }
            Console.WriteLine("Question 1:\nSum of all elements stored in the array is:" + myList_sum);





            //Q2. Write a program in C# Sharp to print all unique elements in an array. 
            int[] myList2 = new int[3];
            myList2[0] = 1;
            myList2[1] = 5;
            myList2[2] = 1;

            Console.WriteLine("\n-------------------\nQuestion 2:\nThe unique elements found in the array are : ");
            int occur = 1;
            for (int i = 0; i < 3; i++)
            {            
                for (int j = 0; j < i; j++)
                {
                    if (myList2[i] == myList2[j])
                    {
                        occur++;
                    }
                }
                if (occur == 1)
                {
                    Console.WriteLine(myList2[i]);
                }
            }





            //Q3 Write a program in C# Sharp for a 2D array of size 3x3 and print the matrix.  
            int[,] myList3 = new int[3, 3];
            myList3[0, 0] = 1;
            myList3[0, 1] = 2;
            myList3[0, 2] = 3;
            myList3[1, 0] = 4;
            myList3[1, 1] = 5;
            myList3[1, 2] = 6;
            myList3[2, 0] = 7;
            myList3[2, 1] = 8;
            myList3[2, 2] = 9;

            Console.WriteLine("\n-------------------\nQuestion 3:\nThe matrix is :");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                    Console.Write(myList3[i, j] + "\t");
                Console.Write("\n");
            }





            //Q4 Write a program in C# Sharp to check the username and password.  
            List<Q4> user_list = new List<Q4>();
            user_list.Add(new Q4("user", "pass"));
            user_list.Add(new Q4("abcd", "1234"));

            Console.WriteLine("\n-------------------\nQuestion 4:\nPlease enter username:");
            var enter_username = Console.ReadLine();

            Console.WriteLine("\nPlease enter password:");
            var enter_password = Console.ReadLine();
            bool correct = false;
            while (correct == false)
            {
                foreach (var i in user_list)
                {

                    if (enter_username == i.username && enter_password == i.password)
                    {
                        correct = true;
                        break;
                    }
                    if (i == user_list.Last())
                    {
                        break;
                    }
                }
                break;
            }
            if (correct == true)
            {
                Console.WriteLine("Password entered successfully! ");
            }
            else
            {
                Console.WriteLine("Wrong Username or Password!! ");
            }




            //Q5 Write a C# Sharp program to compare four sets of words by using each member of the string comparison enumeration.
            //The comparisons use the conventions of the English (United States) and Sami (Upper Sweden) cultures. 
            //Note: The strings "encyclopedia" and "encyclopedia" are considered equivalent in the en-US culture but not in the Sami(Northern Sweden) culture.
            Console.WriteLine("\n-------------------\nQuestion 5:\n");
            String[] culture = { "en-AU", "sv-SE" };
            String[] string1 = { "case",  "encyclopedia",
                            "encyclopedia", "Archeology" };
            String[] string2 = { "Case", "encyclopedia",
                            "encyclopedia" , "ARCHEOLOGY" };
            StringComparison[] comparisons = (StringComparison[])Enum.GetValues(typeof(StringComparison));

            foreach (var cul in culture)
            {
                Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(cul);
                Console.WriteLine("Current Culture: {0}", CultureInfo.CurrentCulture.Name);
                for (int ctr = 0; ctr <= string1.GetUpperBound(0); ctr++)
                {
                    foreach (var comparison in comparisons)
                        Console.WriteLine("   {0} = {1} ({2}): {3}", string1[ctr],
                                          string2[ctr], comparison,
                                          String.Equals(string1[ctr], string2[ctr], comparison));

                    Console.WriteLine();
                }
                Console.WriteLine();
            }





            //Q6 Write a C# Sharp program to convert a given integer value to Roman numerals.  
            Console.WriteLine("\n-------------------\nQuestion 6:");
            int Value1 = 2365;
            int Value2 = 254;
            int Value3 = 45;
            int Value4 = 8;

            Console.WriteLine("\n1.\nOriginal Integer Value: {0}\nRoman numerals of the said integer value: {1}", Value1, Q6(Value1));
            Console.WriteLine("\n2.\nOriginal Integer Value: {0}\nRoman numerals of the said integer value: {1}", Value2, Q6(Value2));
            Console.WriteLine("\n3.\nOriginal Integer Value: {0}\nRoman numerals of the said integer value: {1}", Value3, Q6(Value3));
            Console.WriteLine("\n4.\nOriginal Integer Value: {0}\nRoman numerals of the said integer value: {1}", Value4, Q6(Value4));






            //Q7 Write a program in C# Sharp to generate all possible permutations of an array using recursion.  
            Console.WriteLine("\n-------------------\nQuestion 7:");
            int[] myList4 = new int[3];
            myList4[0] = 1;
            myList4[1] = 2;
            myList4[2] = 3;

            int aCount = 0, bCount = 0, cCount = 0;
            string a = Convert.ToString(myList4[0]);
            string b = Convert.ToString(myList4[1]);
            string c = Convert.ToString(myList4[2]);
            Console.WriteLine("The Permutations with a combination of 3 digits are : ");
            Console.WriteLine("{0}{1}{2}", a, b, c);
            Console.WriteLine("{0}{2}{1}", a, b, c);
            Console.WriteLine("{1}{0}{2}", a, b, c);
            Console.WriteLine("{1}{2}{0}", a, b, c);
            Console.WriteLine("{2}{0}{1}", a, b, c);
            Console.WriteLine("{2}{1}{0}", a, b, c);





            //Q8 Write a program in C# Sharp to display the characters and frequency of character from giving string. (USING LINQ) 
            Console.WriteLine("\n-------------------\nQuestion 8:");
            string test_string = "apple";
            var query = from character in test_string
                        group character by character into g
                        select g;
            Console.Write("The frequency of the characters are :\n");
            foreach (var i in query)
            {
                Console.WriteLine("Character " + i.Key + ": " + i.Count() + " times");
            }




            //Q9 Write a program in C# Sharp to find the string which starts and ends with a specific character. (USING LINQ) 
            Console.WriteLine("\n-------------------\nQuestion 9:");
            string[] cities = new string[] { "ROME", "LONDON", "NAIROBI", "CALIFORNIA", "ZURICH", "NEW DELHI", "AMSTERDAM", "ABU DHABI", "PARIS" };
            string start_string = "A";
            string end_string = "M";
            Console.WriteLine("Input starting character for the string : " + start_string);
            Console.WriteLine("Input starting character for the string : " + end_string);

            Console.WriteLine("\nThe city starting with A and ending with M is: ");

            var q9query = from city in cities
                          where city.StartsWith("A") && city.EndsWith("M")
                          select city;
            foreach (var city in q9query)
            {
                Console.WriteLine(city);
            }





            //Q10 Write a program in C# Sharp to convert a string array to a string. (USING LINQ) 
            Console.WriteLine("\n-------------------\nQuestion 10:");
            String[] stringarray = new String[3] { "cat", "dog", "rat" };
            string q10string = String.Join(", ", stringarray.Select(s => s.ToString()).ToArray());
            Console.WriteLine("\nHere is the string below created with elements of the above array : " + q10string);






            //Q11 Write a program in C# Sharp to create and copy the file to another name and display the content.  
            Console.WriteLine("\n-------------------\nQuestion 11:");
            string mytestfile = "mytest.txt";
            string mytestfile_string = "Hello and Welcome\nIt is the first content\nof the text file mytest.txt";
            File.WriteAllText(mytestfile, mytestfile_string);

            Console.WriteLine("Here is the content of the file mytest.txt :");
            using (StreamReader sr = File.OpenText(mytestfile))
            {
                string s = "";
                while ((s = sr.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
            }

            string mynewtestfile = "mynewtest.txt";
            File.Copy(mytestfile, mynewtestfile, true);
            Console.WriteLine("\nThe file mytest.txt successfully copied to the name mynewtest.txt in the same directory.");

            Console.WriteLine("\nHere is the content of the file mynewtest.txt : ");
            using (StreamReader sr = File.OpenText(mynewtestfile))
            {
                string s = "";
                while ((s = sr.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
            }





            //Q12 Use data base first approach for creating library table with following details :
            //Book id, Book name, Author name, Publishing date, Price
            //Use above table to perform CRUD operation using ENTITY FRAMEWORK.        
            Console.WriteLine("\n-------------------\nQuestion 12:");
            
            //Database has been created with first approach and attached in the zip file ("Q12 - SQL Query...")
            NCS2020Entities mydb= new NCS2020Entities();


            //Inserting
            Console.WriteLine("\n------------------Inserting---------------------");
            Console.WriteLine("Enter New Book ID:");
            int new_id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter New Book Name:");
            string new_name = Console.ReadLine();

            Console.WriteLine("Enter New Book Author Name:");
            string new_authorname = Console.ReadLine();

            Console.WriteLine("Enter New Book Publishing Date:");
            string new_pdate = Console.ReadLine();

            Console.WriteLine("Enter New Book Price:");
            int new_price = Convert.ToInt32(Console.ReadLine());

            Book new_book = new Book()
            {
                Id = new_id,
                Name = new_name,
                Author_Name = new_authorname,
                Publishing_Date = Convert.ToDateTime(new_pdate),
                Price = new_price
            };

            try
            {
                mydb.Books.Add(new_book);
                mydb.SaveChanges();
                Console.WriteLine("Record is inserted successfully !");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Records not inserted successfully! \nReason:" + ex);
            }

            //Reading
            Console.WriteLine("\n------------------Reading---------------------");
            Book[] allbook = mydb.Books.Select(bk => bk).ToArray();
            foreach (var book in allbook)
            {
                Console.WriteLine("\nBook ID: {0}\nBook Name : {1}\nBook Author Name : {2}\nBook Publishing Date :{3}\nBook Price :{4}", book.Id, book.Name, book.Author_Name, book.Publishing_Date, book.Price);
            }


            //Updating
            Console.WriteLine("\n------------------Updating---------------------");
            Console.WriteLine("Enter Book ID to Update:");
            int update_id = Convert.ToInt32(Console.ReadLine());

            try
            {
                Book book = mydb.Books.FirstOrDefault(bk => bk.Id == update_id);
                Console.WriteLine("\nBelow is the information:\nBook ID: {0}\nBook Name : {1}\nBook Author Name : {2}\nBook Publishing Date :{3}\nBook Price :{4}", book.Id, book.Name, book.Author_Name, book.Publishing_Date, book.Price);

                Console.WriteLine("\nEnter New Book Name:");
                string updated_name = Console.ReadLine();

                Console.WriteLine("Enter New Author Name:");
                string updated_authorname = Console.ReadLine();

                Console.WriteLine("Enter New Publishing Date:");
                string updated_pdate = Console.ReadLine();

                Console.WriteLine("Enter New Book Price:");
                int updated_price = Convert.ToInt16(Console.ReadLine());

                book.Name = updated_name;
                book.Author_Name = updated_authorname;
                book.Publishing_Date = Convert.ToDateTime(updated_pdate);
                book.Price = updated_price;
                mydb.SaveChanges();
                Console.WriteLine("Record is updated successfully !");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Records not updated successfully! \nReason:" + ex);
            }


            //Deleting
            Console.WriteLine("\n------------------Deleting---------------------");
            Console.WriteLine("Enter Book ID to Delete:");
            int delete_id = Convert.ToInt32(Console.ReadLine());
            Book del_book = mydb.Books.FirstOrDefault(bk => bk.Id == delete_id);
            try
            {
                mydb.Books.Remove(del_book);
                mydb.SaveChanges();
                Console.WriteLine("Record is removed successfully !");
                Console.WriteLine("\nBelow is the information:\nBook ID: {0}\nBook Name : {1}\nBook Author Name : {2}\nBook Publishing Date :{3}\nBook Price :{4}", del_book.Id, del_book.Name, del_book.Author_Name, del_book.Publishing_Date, del_book.Price);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Records not deleted successfully! \nReason:" + ex);
            }    
        }
    }
}
