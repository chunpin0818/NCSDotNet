﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q13___LinqtoSQL_Dataset
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Q13 Use Library table created above to implement Display all records using LINQ to SQL
            //and LINQ to dataset approach. 
            Console.WriteLine("\n-------------------\nQuestion 13:");

            Console.WriteLine(">>LINQ TO SQL:\nBelow is the information:");
            NCS2020BookDataContext mydata = new NCS2020BookDataContext();
            Book[] LinqSqlQuery = mydata.Books.Select(bk => bk).ToArray();
            foreach (var data in LinqSqlQuery)
            {
                Console.WriteLine("\nBook ID: {0}\nBook Name : {1}\nBook Author Name : {2}\nBook Publishing Date :{3}\nBook Price :{4}", data.Id, data.Name, data.Author_Name, data.Publishing_Date, data.Price);
            }


            Console.WriteLine("\n-----------------------------------------------\n>>LINQ TO Dataset:\nBelow is the information:");
            string conn = "Data Source=.;Initial Catalog=NCS2020;Integrated Security=True";
            string sqlselect = "SELECT * FROM Book";
            SqlDataAdapter da=new SqlDataAdapter(sqlselect,conn);

            da.TableMappings.Add("Table", "Book");
            DataSet ds = new DataSet();
            da.Fill(ds);

            DataTable Book = ds.Tables["Book"];
            var LinqDatasetQuery = from b in Book.AsEnumerable()
                                   select new
                                   {
                                       Book_Id = b.Field<int>("Id"),
                                       Book_Name = b.Field<string>("Name"),
                                       Book_AuthorName = b.Field<string>("Author_Name"),
                                       Book_PublishingDate = b.Field<DateTime>("Publishing_Date"),
                                       Book_Price = b.Field<int>("Price"),
                                   };
            foreach(var data2 in LinqDatasetQuery)
            {
                Console.WriteLine("\nBook ID: {0}\nBook Name : {1}\nBook Author Name : {2}\nBook Publishing Date :{3}\nBook Price :{4}", data2.Book_Id, data2.Book_Name, data2.Book_AuthorName, data2.Book_PublishingDate, data2.Book_Price);
            }
        }
    }
}
